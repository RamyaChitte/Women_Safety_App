package com.example.registration.ui.feed;

import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.Menu;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.registration.R;

public class feedFragment extends Fragment {

    private FeedViewModel mViewModel;

    public static feedFragment newInstance() {
        return new feedFragment();
    }
    EditText sub,msg;
    Button send;
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_feed,container,false);
        sub=view.findViewById(R.id.sub);
        msg=view.findViewById(R.id.msg);
        send=view.findViewById(R.id.send);
                send.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent= new Intent(Intent.ACTION_SENDTO);
                        intent.setData(Uri.parse("mailto:sanjanaiyengar10@gmail.com"));
                       // intent.setType("message/rfc822");
                       // intent.putExtra(Intent.EXTRA_EMAIL,"sanjanaiyengar10@gmail.com");
                        intent.putExtra(Intent.EXTRA_SUBJECT,sub.getText().toString());
                        intent.putExtra(Intent.EXTRA_TEXT,msg.getText().toString());
                        startActivity(intent);
                    }
                });
        return inflater.inflate(R.layout.fragment_feed, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(FeedViewModel.class);
        // TODO: Use the ViewModel
    }

}